package es.indra.business;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import es.indra.clients.UsuariosClienteFeign;
import es.indra.models.Usuario;

@Service
public class UsuariosBSImpl implements IUsuariosBS, UserDetailsService{
	
	@Autowired
	private UsuariosClienteFeign clienteFeign;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Usuario usuario = clienteFeign.findByUsername(username);
		
		if (usuario == null) {
			throw new UsernameNotFoundException("No existe un usuario con ese username " + username);
		}
		
		List<GrantedAuthority> permisos = usuario.getRoles()
				.stream()
				.map(role -> new SimpleGrantedAuthority(role.getNombre()))
				.collect(Collectors.toList());
		
		System.out.println("Usuario autenticado: " + username);
		
		return new User(usuario.getUsername(), usuario.getPassword(), usuario.isEnabled(), 
				true, true, true, permisos);
	}

	@Override
	public Usuario buscarUsuario(String username) {
		return clienteFeign.findByUsername(username);
	}

}
