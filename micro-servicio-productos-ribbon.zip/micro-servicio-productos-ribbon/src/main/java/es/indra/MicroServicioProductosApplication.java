package es.indra;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import es.indra.models.Producto;
import es.indra.persistence.ProductosDAO;

@SpringBootApplication
public class MicroServicioProductosApplication implements CommandLineRunner{
	
	@Autowired   // DI
	ProductosDAO dao; 
	

	// El metodo main esta dedicado exclusivamente a levantar el contexto de Spring
	public static void main(String[] args) {
		SpringApplication.run(MicroServicioProductosApplication.class, args);
	}

	// Este metodo se ejecuta automaticamente a continuacion del metodo main
	@Override
	public void run(String... args) throws Exception {
		
		
		dao.save(new Producto("Prueba", 1234));
		
		dao.findAll().forEach(System.out::println);
		System.out.println("------------------------");
		
		System.out.println(dao.findById(367788L));
		
		System.out.println(dao.findByDescripcion("Teclado"));
		
		System.out.println("------------------------");
		
		dao.findByPrecioBetween(50, 200).forEach(System.out::println);
		System.out.println("------------------------");
		
		dao.findByPrecioBetweenOrderByDescripcion(50, 200).forEach(System.out::println);
		System.out.println("------------------------");
		
		dao.findByPrecioBetweenOrderByDescripcionDesc(50, 200).forEach(System.out::println);
		System.out.println("------------------------");
	}

}
