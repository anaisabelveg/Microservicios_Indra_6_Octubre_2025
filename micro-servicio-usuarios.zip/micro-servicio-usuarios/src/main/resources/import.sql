INSERT INTO usuarios (username, password, enabled, nombre, apellido, email) values ('juan', '$2a$10$cIaXhZMKrUA8rSY5ynADeeaH6Ycwuawt9A2gl2/zsL5HWPZba3.qO', 1, 'Juan', 'Lopez', 'juan@gmail.com');
INSERT INTO usuarios (username, password, enabled, nombre, apellido, email) values ('admin', '$2a$10$FJsHFor1HD5IFcCX81RPd.Q6Fcr8AfBPccmmea72V6hJyA2m2Etym', 1, 'Maria', 'Rodriguez', 'maria@gmail.com');

INSERT INTO roles (nombre) VALUES ('ROLE_USER');
INSERT INTO roles (nombre) VALUES ('ROLE_ADMIN');

INSERT INTO usuarios_roles (usuario_id, role_id) VALUES (1,1);
INSERT INTO usuarios_roles (usuario_id, role_id) VALUES (2,1);
INSERT INTO usuarios_roles (usuario_id, role_id) VALUES (2,2);