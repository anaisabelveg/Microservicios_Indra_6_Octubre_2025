package es.indra.persistence;

import org.springframework.data.jpa.repository.JpaRepository;

import es.indra.models.Valoracion;

public interface ValoracionesDAO extends JpaRepository<Valoracion, Integer>{

}
