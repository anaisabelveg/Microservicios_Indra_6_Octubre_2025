package es.indra.kafka;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import es.indra.business.IValoracionesBS;

@Service
public class Consumidor {
	
	@Autowired
	private IValoracionesBS bs;
	
	@KafkaListener(topics = "indra-cluster")
	public void recibirComentario(String comentario) {
		bs.crearValoracion(comentario);
		
		bs.verTodas().forEach(System.out::println);
	}

}
