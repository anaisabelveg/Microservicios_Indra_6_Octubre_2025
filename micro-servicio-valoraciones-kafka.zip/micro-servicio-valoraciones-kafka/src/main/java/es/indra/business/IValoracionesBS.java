package es.indra.business;

import java.util.List;

import es.indra.models.Valoracion;

public interface IValoracionesBS {
	
	void crearValoracion(String mensaje);
	
	List<Valoracion> verTodas();

}
