package es.indra.persistence;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import es.indra.models.Producto;

// Toda clase que hereda de xxxxReposity en Spring Boot lol detecta como un bean de Spring
// No necesito ponerle anotaciones
public interface ProductosDAO extends JpaRepository<Producto, Long>{
	
	// Podemos crear metodos personalizados utilizando keywords
	// https://docs.spring.io/spring-data/jpa/reference/repositories/query-keywords-reference.html
	
	public List<Producto> findByDescripcion(String descripcion);
	
	public List<Producto> findByPrecioBetween(double min, double max);
	
	public List<Producto> findByPrecioBetweenOrderByDescripcion(double min, double max);
	
	public List<Producto> findByPrecioBetweenOrderByDescripcionDesc(double min, double max);

}
