package es.indra.util;

import javax.validation.ConstraintViolationException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class ManejoExcepcionesGlobales {
	
	// Igual que con try-catch podemos tener multiples catch
	// Aqui podemos tener varios metodos que cada uno capture una excepcion
	
	// No muestra este mensaje sino Producto inexistente
	@ExceptionHandler(ConstraintViolationException.class)
	public ResponseEntity<String> errorValidacion(ConstraintViolationException ex){
		System.out.println("Error de validacion: " + ex.getMessage() + " ---------------");
		return new ResponseEntity<String>("ID no valido", HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(RuntimeException.class)
	public ResponseEntity<String> productoNoExiste(RuntimeException ex){
		System.out.println("Excepcion global capturada: " + ex.getMessage() + " ---------------");
		return new ResponseEntity<String>("Producto inexistente", HttpStatus.NOT_FOUND);
	}
	
	
	@ExceptionHandler(Exception.class)
	public ResponseEntity<String> excepcionGlobal(Exception ex){
		System.out.println("Excepcion inesperada: " + ex.getMessage() + " ---------------");
		return new ResponseEntity<String>("Ha ocurrido un error", HttpStatus.NOT_FOUND);
	}

}
