package es.indra.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import es.indra.business.IPedidosBS;
import es.indra.models.Pedido;
import es.indra.models.Producto;

@RestController
public class PedidosREST {
	
	// Si tengo 2 beans de tipo IPedidosBS da error:
	// 	1ª forma.- cambiamos la anotacion @Autowired por @Resource
	//@Autowired  // no permite elegir el bean por su nombre
	//@Resource(name = "pedidosBSImplFeign")
	//	2ª forma.- dejamos la anotacion @Autowired y utilizamos @Qualifier(nombre)
	//@Autowired
	//@Qualifier(value = "pedidosBSImplFeign")
	//	3ª forma.- dar prioridad al bean que queremos inyectar con @Primary
	@Autowired
	private IPedidosBS bs;
	
	
	// http://localhost:8002/crear/4/cantidad/100
	@GetMapping("/crear/{id}/cantidad/{cantidad}")
	// En el caso de recibir una excepcion invocamos a un metodo alternativo
	//@HystrixCommand(fallbackMethod = "manejarError")
	public Pedido crear(@PathVariable Long id, @PathVariable int cantidad) {
		return bs.crearPedido(id, cantidad);
	}
	
	// El problema de Hystrix es que necesitamos un metodo alternativo por cada
	// operacion del servicio.
	// Si tengo 25 operaciones, necesito 25 metodos alternativos
	// SOLUCION: implementar una captura global de excepciones en una clase aparte
	
	// Este metodo alternativo debe retornar lo mismo que el original
	// y recibir los mismos parametros + excepcion
	public Pedido manejarError(Long id, int cantidad, Throwable ex) {
		System.out.println(ex.getMessage() + " *********************************");
		
		Producto producto = new Producto();
		producto.setID(id);
		producto.setDescripcion("Producto vacio");
		producto.setPrecio(0);
		
		Pedido pedido = new Pedido(producto, cantidad);
		return pedido;
	}

}
