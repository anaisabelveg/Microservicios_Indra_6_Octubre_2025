package es.indra.clients;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import es.indra.models.Pedido;

@FeignClient(name = "servicio-pedidos")
public interface PedidosClienteFeign {
	
	// Mapear la peticion que vamos a emitir
	@GetMapping("/crear/{id}/cantidad/{cantidad}")
	public Pedido crear(@PathVariable Long id, @PathVariable int cantidad);

}
