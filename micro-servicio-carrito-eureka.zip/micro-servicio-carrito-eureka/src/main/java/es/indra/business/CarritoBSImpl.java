package es.indra.business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import es.indra.clients.PedidosClienteFeign;
import es.indra.models.Carrito;
import es.indra.models.Pedido;
import es.indra.persistence.CarritosDAO;

@Service
public class CarritoBSImpl implements ICarritoBS{
	
	@Autowired
	private CarritosDAO dao;
	
	@Autowired
	private PedidosClienteFeign clienteFeign;

	@Override
	public Carrito crear(String usuario) {
		Carrito carrito = consultar(usuario);
		// Solo creo el carrito en el caso de que no exista
		if (carrito == null) {
			carrito = new Carrito();
			carrito.setUsuario(usuario);
			return dao.save(carrito);
		}
		return carrito;
	}

	@Override
	public Carrito agregarPedido(Long id, Integer cantidad, String usuario) {
		Carrito carrito = consultar(usuario);
		Pedido pedido = clienteFeign.crear(id, cantidad);
		carrito.getContenido().add(pedido);
		double importe = carrito.getImporte() + pedido.getProducto().getPrecio() * cantidad;
		carrito.setImporte(importe);
		return dao.save(carrito);
	}

	@Override
	public Carrito consultar(String usuario) {
		return dao.findByUsuario(usuario);
	}

	@Override
	public Carrito eliminarPedido(Long id, String usuario) {
		Carrito carrito = consultar(usuario);
		
		Pedido encontrado = carrito.getContenido().stream()
				.filter(pedido -> pedido.getProducto().getID().equals(id))
				.findFirst()
				.get();
		carrito.getContenido().remove(encontrado);
		double importe = carrito.getImporte() - encontrado.getProducto().getPrecio() * encontrado.getCantidad();
		carrito.setImporte(importe);
		return dao.save(carrito);
	}

}











