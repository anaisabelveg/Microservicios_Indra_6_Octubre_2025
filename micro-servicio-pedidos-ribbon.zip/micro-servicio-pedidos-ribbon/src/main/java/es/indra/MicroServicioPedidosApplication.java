package es.indra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients  // genera el bean del cliente feign
@RibbonClient(name = "servicio-productos")
public class MicroServicioPedidosApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroServicioPedidosApplication.class, args);
	}

}
