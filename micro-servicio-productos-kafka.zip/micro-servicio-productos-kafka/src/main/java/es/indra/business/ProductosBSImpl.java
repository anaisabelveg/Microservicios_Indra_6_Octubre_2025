package es.indra.business;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import es.indra.models.Producto;
import es.indra.persistence.ProductosDAO;

/* En Spring si queremos que la instancia de una clase sea un Bean:
 * 		@Service;  servicios y logica de negocio
 * 		@Repository;  repositorio de datos (dao), ldap, crm, erp
 * 		@Controller;  servlet de Java son controladores en Spring MVC
 * 		@Component; cuando la clase no se comrreponde con ninguna de las anteriores
 * */

@Service
public class ProductosBSImpl implements IProductosBS{
	
	// Solo se pueden hacer inyecciones de dependencias en beans de Spring
	@Autowired
	private ProductosDAO dao;

	@Override
	public List<Producto> consultarTodos() {
		return dao.findAll();
	}

	@Override
	public Producto buscarProducto(Long id) {
		return dao.findById(id).orElse(new Producto());
	}

}
